# La Bombonera Result — Versione 1.0

Prima versione Android dimostrativa.

## Include
- Home
- Pronostico demo
- Area Premium
- Sezione risultati/profilo (interfaccia)
- Avviso di gioco responsabile

## Da aggiungere nella versione successiva
- Backend/database
- Login utenti
- Pannello amministratore per inserire pronostici
- Pagamenti/abbonamenti conformi alle regole di Google Play
- Notifiche
- Statistiche reali
