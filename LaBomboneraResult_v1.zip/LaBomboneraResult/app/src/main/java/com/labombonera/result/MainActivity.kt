package com.labombonera.result

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        findViewById<Button>(R.id.premiumButton).setOnClickListener {
            Toast.makeText(
                this,
                "Area Premium: pagamento da collegare nella prossima versione.",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}
